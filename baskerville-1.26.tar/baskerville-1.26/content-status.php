<div class="post-excerpt">

	<?php the_excerpt( 100 ); ?>

</div><!-- .post-excerpt -->

<?php baskerville_meta(); ?>
            
<div class="clear"></div>